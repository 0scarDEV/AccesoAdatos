package EJ2_A2UD2;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.*;

public class EJ2_A2UD2 {
    private static final String RUTA_ARCHIVO_MAREAS = "mareas.xml";

    public static void main(String[] args) {
        String esquemas="http://apache.org/xml/features/validation/schema";

        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setNamespaceAware(true);
        SAXParser saxParser;
        XMLReader procesador;

        try {
            saxParser = factory.newSAXParser();
            procesador = saxParser.getXMLReader();
            procesador.setFeature(esquemas, true);
        } catch (ParserConfigurationException | SAXException e) {
            throw new RuntimeException(e);
        }

        ManejadorMareas manejador = new ManejadorMareas();
        procesador.setContentHandler(manejador);
        try {
            procesador.parse(new InputSource(new FileInputStream(RUTA_ARCHIVO_MAREAS)));
        } catch (IOException | SAXException e) {
            throw new RuntimeException(e);
        }

        StringBuilder descDoc = manejador.getStringBuilder();
        System.out.println(descDoc);
    }
}
