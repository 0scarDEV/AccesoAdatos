package E2_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Scanner;

public class E2_1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char opcion;
        File[] roots = File.listRoots();

        System.out.print("Menu de opciones" +
                           "\n----------------" +
                           "\n[P] listado por pantalla" +
                           "\n[F] listado a un fichero" +
                           "\n----------------" +
                           "\nElija opción --------------> ");
        opcion = sc.nextLine().charAt(0);

        switch (opcion) {
            case 'P' -> listadoPantalla(roots);
            case 'F' -> listadoFichero(roots);
            default -> System.out.println("Opción no válida");
        }
    }

    private static void listadoFichero(File[] roots) {
        String ruta = "src/A2UD1_ÓscarFernándezPastoriza/E2_1/listado.txt";
        for (File root : roots) {
            try (PrintStream pw = new PrintStream(new FileOutputStream(ruta, true))) {
                pw.print(getInfo(root) + "\n");
            } catch (FileNotFoundException e) {
                System.out.println("Error al abrir el fichero.");
            }
        }
    }

    private static void listadoPantalla(File[] roots) {
        for (File root : roots) {
            System.out.println(getInfo(root));
        }
    }

    private static String getInfo(File root) {
        long freeSpace = root.getFreeSpace();
        long totalSpace = root.getTotalSpace();
        long occupiedSpace = totalSpace - freeSpace;

        NumberFormat nf = NumberFormat.getInstance();
        DecimalFormat df = new DecimalFormat("#0.000");

        return "Unidad: " + root.getAbsolutePath() +
                "\n\tEspacio libre: " + nf.format(freeSpace) + " bytes. (" + df.format(getGB(freeSpace))  + " GB)" +
                "\n\tEspacio ocupado: " + nf.format(occupiedSpace) + " bytes. (" + df.format(getGB(occupiedSpace)) + " GB)" +
                "\n\tEspacio total: " + nf.format(totalSpace) + " bytes. (" + df.format(getGB(totalSpace)) + " GB)";
    }

    public static double getGB(long bytes) {
        return (double) bytes / (1024 * 1024 * 1024);
    }
}
