package E2_4;

import Comunes.Comunes;
import Comunes.FiltroTerminaCon;

import java.io.File;
import java.text.DecimalFormat;
import java.util.Scanner;

public class E2_4 {

    public static void main(String[] args) throws Comunes.ExcepcionNoEsUnDirectorio, Comunes.ExcepcionRutaNoValida {
        // Variables
        Scanner sc = new Scanner(System.in);
        String ruta;
        String extension;
        File directorio;

        // Pedimos datos
        System.out.print("Introduce una ruta: ");
        ruta = sc.nextLine();
        System.out.print("Introduce la extensión del archivo a buscar: (.extension)");
        extension = sc.nextLine();

        directorio = new File(ruta);

        // Comprobaciones
        if (directorio.exists()) {
            if (directorio.isDirectory()) {
                listarPorExtension(directorio, extension);
            } else {
                throw new Comunes.ExcepcionNoEsUnDirectorio();
            }
        } else {
            throw new Comunes.ExcepcionRutaNoValida();
        }
    }

    private static void listarPorExtension(File directorio, String extension) {
        File[] archivos = directorio.listFiles(new FiltroTerminaCon(extension));
        DecimalFormat df = new DecimalFormat("#0.000");

        System.out.println("----- LISTANDO EL DIRECTORIO " + directorio.getAbsolutePath() + " CON LA EXTENSIÓN " + extension.toUpperCase());
        for (File archivo : archivos) {
            double kb = archivo.length() / 1024.0;
            System.out.println("-|" + archivo.getName() + (archivo.isFile()
                    ? " <FICHERO> " + df.format(kb) + " Kbytes " + Comunes.getUltModif(archivo)
                    : archivo.isDirectory() ? "<DIR>" : "<DESCONOCIDO>"));
        }
    }
}
