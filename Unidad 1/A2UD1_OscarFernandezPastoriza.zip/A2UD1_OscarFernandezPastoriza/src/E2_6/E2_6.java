package E2_6;

import java.io.File;
import java.text.DecimalFormat;
import java.util.Scanner;
import static Comunes.Comunes.*;

public class E2_6 {
    public static void main(String[] args) throws ExcepcionNoEsUnDirectorio, ExcepcionRutaNoValida {
        Scanner sc = new Scanner(System.in);
        String ruta, subcadena;
        File directorio;

        System.out.print("Introduce una ruta: ");
        ruta = sc.nextLine();
        System.out.print("Introduce una subcadena: ");
        subcadena = sc.nextLine();

        directorio = new File(ruta);
        if (directorio.exists()) {
            if (directorio.isDirectory()) {
                System.out.println("Listado del directorio: " + directorio.getAbsolutePath());
                listarDirectorio(directorio, 0, subcadena);
            } else {
                throw new ExcepcionNoEsUnDirectorio();
            }
        } else {
            throw new ExcepcionRutaNoValida();
        }
    }

    private static void listarDirectorio(File directorio, int nivel, String subcadena) {
        File[] archivos = directorio.listFiles();
        DecimalFormat df = new DecimalFormat("#0.000");

        if (archivos != null) {
            for (File ruta : archivos) {
                if (ruta.getName().contains(subcadena)) {
                    StringBuilder info = new StringBuilder();

                    for (int i = 0; i <= nivel; i++) {
                        info.append("---");
                    }
                    info.append("|" + ruta.getName());
                    if (ruta.isDirectory()) {
                        info.append(" <DIR>");
                        System.out.println(info);
                        listarDirectorio(ruta, nivel + 1, subcadena);
                    } else if (ruta.isFile()) {
                        info.append(" <FICHERO> " + df.format(ruta.length() / 1024.0) + " Kbytes " + getUltModif(ruta));
                        System.out.println(info);
                    } else {
                        info.append(" <DESCONOCIDO>");
                        System.out.println(info);
                    }
                }
            }
        }
    }
}
