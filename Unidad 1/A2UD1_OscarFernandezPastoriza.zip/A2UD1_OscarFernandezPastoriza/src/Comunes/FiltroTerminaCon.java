package Comunes;

import java.io.File;
import java.io.FilenameFilter;

public class FiltroTerminaCon implements FilenameFilter {
    String extension;

    public FiltroTerminaCon(String extension) {
        this.extension = extension;
    }

    @Override
    public boolean accept(File dir, String name) {
        return name.endsWith(extension);
    }
}