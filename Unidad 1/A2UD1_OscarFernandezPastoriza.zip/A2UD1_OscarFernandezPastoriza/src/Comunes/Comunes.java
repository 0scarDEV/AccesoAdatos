package Comunes;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Comunes {
    public static class ExcepcionNoEsUnDirectorio extends Exception {
        public ExcepcionNoEsUnDirectorio() {
            super("la ruta no es un directorio");
        }
    }
    public static class ExcepcionRutaNoValida extends Exception {
        public ExcepcionRutaNoValida() {
            super("la ruta especificada no existe");
        }
    }
    public static String getUltModif(File archivo) {
        Date fecha = new Date(archivo.lastModified());
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        return formatoFecha.format(fecha);
    }
    public static double getKB(long bytes) {
        return (double) bytes / 1024;
    }
}
