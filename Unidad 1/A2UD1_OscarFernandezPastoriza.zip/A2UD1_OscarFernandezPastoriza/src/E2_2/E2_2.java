package E2_2;

import Comunes.Comunes;
import java.io.File;
import java.text.DecimalFormat;
import java.util.Scanner;
import static Comunes.Comunes.*;

public class E2_2 {
    public static void main(String[] args) throws Comunes.ExcepcionNoEsUnDirectorio, Comunes.ExcepcionRutaNoValida {
        Scanner sc = new Scanner(System.in);
        String ruta;
        File directorio;
        DecimalFormat df = new DecimalFormat("#0.000");

        System.out.print("Introduce una ruta: ");
        ruta = sc.nextLine();

        directorio = new File(ruta);

        if (directorio.exists()) {
            if (directorio.isDirectory()) {
                File[] archivos = directorio.listFiles();
                System.out.println("----- LISTANDO EL DIRECTORIO " + directorio.getAbsolutePath());
                for (File archivo : archivos) {
                    double kb = getKB(archivo.length());

                    /* Ternario */
                    System.out.println("-|" + archivo.getName() + (archivo.isFile()
                            ? " <FICHERO> " + df.format(kb) + " Kbytes " + getUltModif(archivo)
                            : archivo.isDirectory() ? "<DIR>" : "<DESCONOCIDO>"));

                        /* IFs
                        String info = "-|" + archivo.getName();

                        if (archivo.isFile()) {
                            info += " <FICHERO> " + df.format(kb) + " Kbytes " + getUltModif(archivo);
                        } else if (archivo.isDirectory()) {
                            info += "<DIR>";
                        } else {
                            info += "<DESCONOCIDO>";
                        }

                        System.out.println(info); */
                }
            } else {
                throw new Comunes.ExcepcionNoEsUnDirectorio();
            }
        } else {
            throw new Comunes.ExcepcionRutaNoValida();
        }
    }
}