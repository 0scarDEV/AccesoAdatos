package E2_3;

import Comunes.Comunes;
import java.io.File;
import java.text.DecimalFormat;
import java.util.Scanner;
import static Comunes.Comunes.*;

public class E2_3 {
    public static void main(String[] args) throws Comunes.ExcepcionNoEsUnDirectorio, Comunes.ExcepcionRutaNoValida {
        Scanner sc = new Scanner(System.in);
        String ruta;
        File directorio;

        System.out.print("Introduce una ruta: ");
        ruta = sc.nextLine();

        directorio = new File(ruta);
        if (directorio.exists()) {
            if (directorio.isDirectory()) {
                System.out.println("Listado del directorio: " + directorio.getAbsolutePath());
                listarDirectorio(directorio, 0);
            } else {
                throw new Comunes.ExcepcionNoEsUnDirectorio();
            }
        } else {
            throw new Comunes.ExcepcionRutaNoValida();
        }
    }

    private static void listarDirectorio(File directorio, int nivel) {
        File[] archivos = directorio.listFiles();
        DecimalFormat df = new DecimalFormat("#0.000");

        if (archivos != null) {
            for (File ruta : archivos) {
                StringBuilder info = new StringBuilder();

                for (int i = 0; i <= nivel; i++) {
                    info.append("---");
                }
                info.append("|" + ruta.getName());

                if (ruta.isDirectory()) {
                    info.append(" <DIR>");
                    System.out.println(info);
                    listarDirectorio(ruta, nivel + 1);
                } else if (ruta.isFile()) {
                    info.append(" <FICHERO> " + df.format(ruta.length() / 1024.0) + " Kbytes " + Comunes.getUltModif(ruta));
                    System.out.println(info);
                } else {
                    info.append(" <DESCONOCIDO>");
                    System.out.println(info);
                }
            }
        }
    }
}
