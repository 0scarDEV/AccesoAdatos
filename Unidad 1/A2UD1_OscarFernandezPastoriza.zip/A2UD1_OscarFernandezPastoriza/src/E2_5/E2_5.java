package E2_5;

import Comunes.*;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class E2_5 {

    public static void main(String[] args) throws Comunes.ExcepcionNoEsUnDirectorio, Comunes.ExcepcionRutaNoValida {
        // Variables
        Scanner sc = new Scanner(System.in);
        String ruta;
        String extension;
        File directorio;

        // Pedimos datos
        System.out.print("Introduce una ruta: ");
        ruta = sc.nextLine();
        System.out.print("Introduce la extensión del archivo a buscar: (.extension)");
        extension = sc.nextLine();

        directorio = new File(ruta);

        // Comprobaciones
        if (directorio.exists()) {
            if (directorio.isDirectory()) {
                listarExtOrdenada(directorio, extension);
            } else {
                throw new Comunes.ExcepcionNoEsUnDirectorio();
            }
        } else {
            throw new Comunes.ExcepcionRutaNoValida();
        }
    }

    private static void listarExtOrdenada(File directorio, String extension) {
        File[] archivos = directorio.listFiles(new FiltroTerminaCon(extension));
        DecimalFormat df = new DecimalFormat("#0.000");

        if (archivos != null) {
            ArrayList<File> fileList = new ArrayList<>(List.of(archivos));
            fileList.sort((fileA, fileB) -> fileA.getName().compareToIgnoreCase(fileB.getName()));

            System.out.println("----- LISTANDO EL DIRECTORIO " + directorio.getAbsolutePath() + " CON LA EXTENSIÓN " + extension.toUpperCase());
            for (File archivo : fileList) {
                double kb = archivo.length() / 1024.0;
                System.out.println("-|" + archivo.getName() + (archivo.isFile()
                        ? " <FICHERO> " + df.format(kb) + " Kbytes " + Comunes.getUltModif(archivo)
                        : archivo.isDirectory() ? "<DIR>" : "<DESCONOCIDO>"));
            }
        }
    }
}
