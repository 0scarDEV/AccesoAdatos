package E3_2;

public class NumeroMenorException extends Throwable {

}
