package E31_P4;

public class DorsalNoRegistradoException extends Exception {
    public DorsalNoRegistradoException() {
        super();
    }
}
