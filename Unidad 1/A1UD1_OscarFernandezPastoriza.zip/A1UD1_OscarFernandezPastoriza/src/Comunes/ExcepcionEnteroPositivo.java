package Comunes;

public class ExcepcionEnteroPositivo extends Exception {
    public ExcepcionEnteroPositivo() {
        super("El número debe ser positivo.");
    }
}