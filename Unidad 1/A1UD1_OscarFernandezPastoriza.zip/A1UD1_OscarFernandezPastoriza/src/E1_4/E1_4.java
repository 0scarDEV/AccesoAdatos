package E1_4;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

public class E1_4 {
    static String ruta = "src/A1UD1_ÓscarFernándezPastoriza/E1_4/NumerosPositivos.txt";
    public static void main(String[] args) throws FileNotFoundException {
        ArrayList<Integer> lista = new ArrayList<>();

        String[] numerosEnteros = leerNumerosEnteros().split(";");
        for (String numero : numerosEnteros) {
            lista.add(Integer.parseInt(numero));
        }

        lista.sort(Comparator.naturalOrder());

        for (Integer numero : lista) {
            grabarFichero(numero);
        }
    }

    private static String leerNumerosEnteros() throws FileNotFoundException {
        String contenido;
        Scanner sc = new Scanner(new FileReader(ruta));
        contenido = sc.nextLine();
        return contenido;
    }

    public static void grabarFichero(int contenido) {
        try (PrintStream pw = new PrintStream(new FileOutputStream(ruta, true))) {
            pw.print(contenido + ";");
        } catch (FileNotFoundException e) {
            System.out.println("Error al abrir el fichero.");
        }
    }
}
