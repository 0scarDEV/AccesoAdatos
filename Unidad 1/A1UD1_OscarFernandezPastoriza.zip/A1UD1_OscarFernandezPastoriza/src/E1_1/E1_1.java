package E1_1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class E1_1 {
    public static void main(String[] args) throws IOException {
        int[] enteros = leerEnteros();

        System.out.print("La suma es: " + (enteros[0]+enteros[1]) + "\n");
        System.out.print("La resta es: " + (enteros[0]-enteros[1]) + "\n");
        System.out.print("La multiplicación es: " + (enteros[0]*enteros[1]) + "\n");
        try {
            System.out.print("La división es: " + (enteros[0]/enteros[1]) + "\n");
        } catch (ArithmeticException ae) {
            System.out.println("No se puede dividir entre cero.");
        }
        System.out.print("La división real es: " + ((double)enteros[0]/(double)enteros[1]) + "\n");
        try {
            System.out.print("El resto es: " + (enteros[0]%enteros[1]) + "\n");
        } catch (ArithmeticException ae) {
            System.out.println("No se puede obtener el resto si el segundo número es cero.");
        }
    }
    private static int[] leerEnteros() throws IOException {
        BufferedReader brEntrada = new BufferedReader(new InputStreamReader(System.in));
        int[] nums = new int[2];
        int num1, num2;
        String entrada1, entrada2;

        System.out.print("Introduce primer numero entero: ");
        try {
            entrada1 = brEntrada.readLine();
            num1 = Integer.parseInt(entrada1);
            nums[0] = num1;
        } catch (NumberFormatException nfe) {
            System.out.println("numero no es un entero. Intentalo de nuevo: ");
            entrada1 = brEntrada.readLine();
            num1 = Integer.parseInt(entrada1);
            nums[0] = num1;
        }

        System.out.print("Introduce segundo numero entero: ");
        try {
            entrada2 = brEntrada.readLine();
            num2 = Integer.parseInt(entrada2);
            nums[1] = num2;
        } catch (NumberFormatException nfe) {
            System.out.println("numero no es un entero. Intentalo de nuevo: ");
            entrada2 = brEntrada.readLine();
            num2 = Integer.parseInt(entrada2);
            nums[1] = num2;
        }

        return nums;
    }
}
