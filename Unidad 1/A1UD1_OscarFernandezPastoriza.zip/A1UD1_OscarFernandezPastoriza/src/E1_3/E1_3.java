package E1_3;

import Comunes.ExcepcionEnteroPositivo;
import java.io.*;
import java.util.Scanner;

public class E1_3 {
    private static final String ruta = "NumerosPositivos.txt";
    public static void main (String[] args) throws IOException, ExcepcionEnteroPositivo {
        abrirFichero();
        System.out.println("Introduce el número de enteros positivos para grabar en fichero:");
        int num = leerPositivo();
        for (int i = 1; i <= num; i++) {
            System.out.print("número " + i + ":");
            grabarFichero(leerPositivo());
        }
        cerrarFichero();
        leerFichero();
    }

    private static void cerrarFichero() {
        new File(ruta).setReadOnly();
    }

    private static void leerFichero() throws FileNotFoundException {
        Scanner sc = new Scanner(new FileReader(ruta));
        System.out.println(sc.nextLine());
    }

    private static void abrirFichero() throws IOException {
        new File(ruta).createNewFile();
    }

    public static void grabarFichero(int contenido) {
        try (PrintStream pw = new PrintStream(new FileOutputStream(ruta, true))) {
            pw.print(contenido + ";");
        } catch (FileNotFoundException e) {
            System.out.println("Error al abrir el fichero.");
        }
    }

    public static int leerPositivo() throws ExcepcionEnteroPositivo {
        int valor = 0;
        boolean flag = true;
        Scanner sc = new Scanner(System.in);

        while(flag) {
            try {
                valor = sc.nextInt();
                if (valor < 0) {
                    throw new ExcepcionEnteroPositivo();
                } else {
                    flag = false;
                }
            } catch (NumberFormatException e) {
                System.out.println("No es un número entero.");
            }
        }

        return valor;
    }
}
