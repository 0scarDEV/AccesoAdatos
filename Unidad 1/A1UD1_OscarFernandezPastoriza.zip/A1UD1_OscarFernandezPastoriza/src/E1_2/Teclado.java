package E1_2;

import Comunes.ExcepcionEnteroPositivo;
import java.io.*;

public class Teclado {
    static BufferedReader brEntrada = new BufferedReader(new InputStreamReader(System.in));

    public static String leer() throws IOException {
        return brEntrada.readLine();
    }

    public static char leerChar() throws IOException {
        return brEntrada.readLine().charAt(0);
    }

    public static int leerInt() throws IOException {
        return Integer.parseInt(brEntrada.readLine());
    }

    public static double leerDouble() throws IOException {
        return Double.parseDouble(brEntrada.readLine());
    }

    public static double leerPositivo() throws Exception {
        double valor = 0;
        boolean flag = true;
        while(flag) {
            try {
                valor = Integer.parseInt(leer());
                if (valor < 0) {
                    throw new ExcepcionEnteroPositivo();
                } else {
                    flag = false;
                }
            } catch (NumberFormatException e) {
                System.out.println("No es un número entero.");
            } catch (ExcepcionEnteroPositivo e) {
                System.out.println("El número debe ser positivo.");
            }
        }
        return valor;
    }

    public static void guardarEnArchivo(String contenido) throws IOException {
        String ruta = "Datos.txt";
        BufferedWriter out = new BufferedWriter(new FileWriter(ruta));
        out.write(contenido);
        out.flush();
        out.close();
    }

    public static void main(String[] args) throws Exception {
        String s = Teclado.leer();
        char car = Teclado.leerChar();
        int num1 = Teclado.leerInt();
        double num2 = Teclado.leerDouble();
        int num3 = (int) Teclado.leerPositivo();

        String resultado = "cadena: " + s
                + "\nEl caracter tecleado: " + car
                + "\nentero: " + num1
                + "\nnumero real double: " + num2
                + "\nnumero entero positivo " + num3;

        Teclado.guardarEnArchivo(resultado);
    }
}