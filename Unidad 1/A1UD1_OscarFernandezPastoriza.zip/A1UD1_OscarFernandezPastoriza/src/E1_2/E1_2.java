package E1_2;

import java.io.*;

public class E1_2 {
    public static void main (String[] args) throws IOException {
        PrintStream out = System.out;
        out.print("Leer cadena: ");
        String s = Teclado.leer();
        out.print("Leer caracter: ");
        char car = Teclado.leerChar();
        out.print("Leer numero entero: ");
        int num1 = Teclado.leerInt();
        out.print("Leer numero double: ");
        double num2 = Teclado.leerDouble();
        out.println(" cadena: "+s);
        out.println(" caracter: "+car);
        out.println(" entero: "+num1);
        out.println(" numero real double: "+num2);

        String resultado = "cadena: " + s
                + "\nEl caracter tecleado: " + car
                + "\nentero: " + num1
                + "\nnumero real double: " + num2;

        Teclado.guardarEnArchivo(resultado);
    }
}