package ejercicio5_2;

import java.sql.Date;

public class VehiculoRenting extends Vehiculo {
    Date fechaInicio;
    double precioMensual;

    public VehiculoRenting(String matricula, String marca, String modelo, char combustible, Date fechaInicio, double precioMensual) {
        super(matricula, marca, modelo, combustible);
        this.fechaInicio = fechaInicio;
        this.precioMensual = precioMensual;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public double getPrecioMensual() {
        return precioMensual;
    }

    public void setPrecioMensual(double precioMensual) {
        this.precioMensual = precioMensual;
    }
}
